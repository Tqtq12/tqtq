PrefabFiles = {
	"tequeteque",
	"tequeteque_none",
}

Assets = {
    Asset( "IMAGE", "images/saveslot_portraits/tequeteque.tex" ),
    Asset( "ATLAS", "images/saveslot_portraits/tequeteque.xml" ),
	
	Asset( "IMAGE", "images/saveslot_portraits/tequeteque_none.tex" ),
    Asset( "ATLAS", "images/saveslot_portraits/tequeteque_none.xml" ),

    Asset( "IMAGE", "images/selectscreen_portraits/tequeteque.tex" ),
    Asset( "ATLAS", "images/selectscreen_portraits/tequeteque.xml" ),
	
    Asset( "IMAGE", "images/selectscreen_portraits/tequeteque_silho.tex" ),
    Asset( "ATLAS", "images/selectscreen_portraits/tequeteque_silho.xml" ),

    Asset( "IMAGE", "bigportraits/tequeteque.tex" ),
    Asset( "ATLAS", "bigportraits/tequeteque.xml" ),
	
	Asset( "IMAGE", "images/map_icons/tequeteque.tex" ),
	Asset( "ATLAS", "images/map_icons/tequeteque.xml" ),
	
	Asset( "IMAGE", "images/avatars/avatar_tequeteque.tex" ),
    Asset( "ATLAS", "images/avatars/avatar_tequeteque.xml" ),
	
	Asset( "IMAGE", "images/avatars/avatar_ghost_tequeteque.tex" ),
    Asset( "ATLAS", "images/avatars/avatar_ghost_tequeteque.xml" ),
	
	Asset( "IMAGE", "images/avatars/self_inspect_tequeteque.tex" ),
    Asset( "ATLAS", "images/avatars/self_inspect_tequeteque.xml" ),
	
	Asset( "IMAGE", "images/names_tequeteque.tex" ),
    Asset( "ATLAS", "images/names_tequeteque.xml" ),
	
	Asset( "IMAGE", "images/names_gold_tequeteque.tex" ),
    Asset( "ATLAS", "images/names_gold_tequeteque.xml" ),
	
	Asset( "SOUNDPACKAGE", "sound/tequeteque.fev" ),
    Asset( "SOUND", "sound/tequeteque.fsb" ),
}

RemapSoundEvent("dontstarve/characters/tequeteque","tequeteque/tequeteque")
RemapSoundEvent("dontstarve/characters/tequeteque/talk_LP","tequeteque/tequeteque/talk_P")
RemapSoundEvent("dontstarve/characters/tequeteque/ghost_LP","tequeteque/tequeteque/ghost_LP")
RemapSoundEvent("dontstarve/characters/tequeteque/hurt","tequeteque/tequeteque/hurt")
RemapSoundEvent("dontstarve/characters/tequeteque/death_voice","tequeteque/tequeteque/death_voice")
RemapSoundEvent("dontstarve/characters/tequeteque/emote","tequeteque/tequeteque/emote")
RemapSoundEvent("dontstarve/characters/tequeteque/pose","tequeteque/tequeteque/pose")
RemapSoundEvent("dontstarve/characters/tequeteque/yawn","tequeteque/tequeteque/yawn")

AddMinimapAtlas("images/map_icons/tequeteque.xml")

local require = GLOBAL.require
local STRINGS = GLOBAL.STRINGS

-- The character select screen lines
STRINGS.CHARACTER_TITLES.tequeteque = "The Coolest Streamer"
STRINGS.CHARACTER_NAMES.tequeteque = "Tequeteque"
STRINGS.CHARACTER_DESCRIPTIONS.tequeteque = "Cool guy!\Yerp.\Cool guy!"
STRINGS.CHARACTER_QUOTES.tequeteque = "\"Time to mine and craft!\""
STRINGS.CHARACTER_SURVIVABILITY.tequeteque = "Slim"

-- Custom speech strings
STRINGS.CHARACTERS.tequeteque = require "speech_tequeteque"

-- The character's name as appears in-game 
STRINGS.NAMES.tequeteque = "tequeteque"
STRINGS.SKIN_NAMES.tequeteque_none = "tequeteque"

-- The skins shown in the cycle view window on the character select screen.
-- A good place to see what you can put in here is in skinutils.lua, in the function GetSkinModes
local skin_modes = {
    { 
        type = "ghost_skin",
        anim_bank = "ghost",
        idle_anim = "idle", 
        scale = 0.75, 
        offset = { 0, -25 } 
    },
}

-- Add mod character to mod character list. Also specify a gender. Possible genders are MALE, FEMALE, ROBOT, NEUTRAL, and PLURAL.
AddModCharacter("tequeteque", "MALE", skin_modes)
