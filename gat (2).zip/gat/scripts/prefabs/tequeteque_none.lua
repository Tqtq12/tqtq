local assets =
{
	Asset( "ANIM", "anim/tequeteque.zip" ),
	Asset( "ANIM", "anim/ghost_tequeteque_build.zip" ),
}

local skins =
{
	normal_skin = "tequeteque",
	ghost_skin = "ghost_tequeteque_build",
}

return CreatePrefabSkin("tequeteque_none",
{
	base_prefab = "tequeteque",
	type = "base",
	assets = assets,
	skins = skins, 
	skin_tags = {"tequeteque", "CHARACTER", "BASE"},
	build_name_override = "tequeteque",
	rarity = "Character",
})